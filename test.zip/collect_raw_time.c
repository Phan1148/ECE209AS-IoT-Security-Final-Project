#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <x86intrin.h>  // For clflush instruction

#define SAMPLES 10000

// Custom flush function
static inline void my_flush(void *p) {
    asm volatile ("clflush 0(%0)\n" : : "r" (p) : "memory");
}

// Custom timing function
static inline uint64_t get_time() {
    unsigned int aux;
    return __rdtscp(&aux);
}

int main() {
    volatile char *buffer = malloc(4096);
    
    // Initialize memory content
    for (int i = 0; i < 4096; i++) {
        buffer[i] = i & 0xff;
    }
    
    printf("timestamp,access_time,cache_hit,type\n");
    
    // Collect cache hit times
    for (int i = 0; i < SAMPLES; i++) {
        // First access to ensure it's in cache
        buffer[0] = 1;
        
        // Measure cache access time
        uint64_t start = get_time();
        volatile char temp = buffer[0];
        uint64_t time = get_time() - start;
        
        printf("%d,%lu,1,normal\n", i, time);
    }
    
    // Collect memory access times
    for (int i = 0; i < SAMPLES; i++) {
        // Flush from cache
        my_flush((void*)buffer);
        
        // Measure memory access time
        uint64_t start = get_time();
        volatile char temp = buffer[0];
        uint64_t time = get_time() - start;
        
        printf("%d,%lu,0,normal\n", i + SAMPLES, time);
    }
    
    // Simulate Flush+Reload attack pattern
    for (int i = 0; i < SAMPLES*2; i++) {
        if (i % 2 == 0) {
            // Flush
            my_flush((void*)buffer);
            uint64_t start = get_time();
            volatile char temp = buffer[0];
            uint64_t time = get_time() - start;
            printf("%d,%lu,0,flush_reload\n", i + SAMPLES*2, time);
        } else {
            // Reload (already in cache)
            uint64_t start = get_time();
            volatile char temp = buffer[0];
            uint64_t time = get_time() - start;
            printf("%d,%lu,1,flush_reload\n", i + SAMPLES*2, time);
        }
    }
    
    free((void*)buffer);
    return 0;
}
