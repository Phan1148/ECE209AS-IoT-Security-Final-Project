#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <x86intrin.h>

#define SAMPLES 10000
#define CACHE_LINE_SIZE 64
#define L1_WAYS 8  // Typical L1 cache associativity
#define CACHE_SET_SIZE (L1_WAYS * CACHE_LINE_SIZE)

// Custom timing function
static inline uint64_t get_time() {
    unsigned int aux;
    return __rdtscp(&aux);
}

// Function to create addresses that map to the same cache set
char** create_eviction_set(int size) {
    char** addresses = malloc(size * sizeof(char*));
    for (int i = 0; i < size; i++) {
        // Allocate memory aligned to cache line size
        addresses[i] = (char*)malloc(CACHE_LINE_SIZE);
        // Initialize memory
        addresses[i][0] = i;
    }
    return addresses;
}

int main() {
    srand(time(NULL));
    char** eviction_set = create_eviction_set(L1_WAYS + 1);
    
    printf("timestamp,access_time,cache_hit,type\n");
    
    // Generate normal access pattern (mixed cache hits/misses)
    for (int i = 0; i < SAMPLES; i++) {
        // Random access - sometimes hit, sometimes miss
        int index = rand() % (L1_WAYS + 1);
        uint64_t start = get_time();
        volatile char temp = eviction_set[index][0];
        uint64_t time = get_time() - start;
        
        int cache_hit = (time < 100) ? 1 : 0;  // Approximate threshold
        printf("%d,%lu,%d,normal\n", i, time, cache_hit);
    }
    
    // Generate Prime+Probe pattern
    for (int i = 0; i < SAMPLES * 2; i++) {
        if (i % 2 == 0) {
            // Prime: Fill the cache set
            for (int j = 0; j < L1_WAYS; j++) {
                eviction_set[j][0] = j;  // Access the address
            }
            printf("%d,0,1,prime_probe\n", i + SAMPLES);  // Dummy entry for prime
        } else {
            // Probe: Measure access times to detect eviction
            // Simulate some evictions (as if a victim process used the cache)
            int evicted = rand() % L1_WAYS;
            
            // Access all addresses and time them
            for (int j = 0; j < L1_WAYS; j++) {
                uint64_t start = get_time();
                volatile char temp = eviction_set[j][0];
                uint64_t time = get_time() - start;
                
                // If the index matches the "evicted" one, this should be a cache miss
                int cache_hit = (j == evicted) ? 0 : 1;
                printf("%d,%lu,%d,prime_probe\n", i + SAMPLES + j, time, cache_hit);
            }
        }
    }
    
    // Free allocated memory
    for (int i = 0; i < L1_WAYS + 1; i++) {
        free(eviction_set[i]);
    }
    free(eviction_set);
    
    return 0;
}
