









    volatile char temp = buffer[0];
            uint32_t time = rdtscp() - start;
            printf("%d,%u,1,flush_reload\n", i + SAMPLES*2, time);
        }
    }
    
    free((void*)buffer);
    return 0;
}
