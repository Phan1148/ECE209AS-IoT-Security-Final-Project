#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <x86intrin.h>
#include <unistd.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>

#define SAMPLES 2000  // Adjust to get ~6000 total rows when combined

// Custom timing function
static inline uint64_t get_time() {
    unsigned int aux;
    return __rdtscp(&aux);
}

// Custom flush function
static inline void my_flush(void *p) {
    asm volatile ("clflush 0(%0)\n" : : "r" (p) : "memory");
}

// Get CPU usage (user time + system time)
double get_cpu_usage() {
    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    return usage.ru_utime.tv_sec + usage.ru_stime.tv_sec + 
          (usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1000000.0;
}

// Generate descriptive memory access pattern
const char* get_memory_pattern(int pattern_type, int variation) {
    static char pattern_str[64];
    
    switch (pattern_type) {
        case 0:
            sprintf(pattern_str, "sequential_access_%d", variation);
            break;
        case 1:
            sprintf(pattern_str, "random_access_%d", variation);
            break;
        case 2:
            sprintf(pattern_str, "stride_access_%d", variation);
            break;
        case 3:
            sprintf(pattern_str, "block_access_%d", variation);
            break;
        default:
            sprintf(pattern_str, "unknown_pattern");
    }
    
    return pattern_str;
}

int main() {
    volatile char *buffer = malloc(4096);
    double timestamp = 0.0;
    
    // Initialize memory content
    for (int i = 0; i < 4096; i++) {
        buffer[i] = i & 0xff;
    }
    
    printf("timestamp,access_time,cache_hit,attack_type,cpu_usage,memory_access_pattern\n");
    
    double start_cpu = get_cpu_usage();
    srand(time(NULL));
    
    // Collect cache hit times (normal behavior)
    for (int i = 0; i < SAMPLES; i++) {
        buffer[0] = 1;  // Ensure in cache
        
        // Generate pattern based on access type
        int pattern_type = i % 4;
        int variation = rand() % 10;
        const char* pattern = get_memory_pattern(pattern_type, variation);
        
        uint64_t start = get_time();
        volatile char temp = buffer[0];
        uint64_t time = get_time() - start;
        
        double cpu = get_cpu_usage() - start_cpu;
        timestamp += 0.01 + (rand() % 10) / 1000.0;  // Small random increment
        
        printf("%.6f,%lu,1,normal,%.6f,%s\n", timestamp, time, cpu, pattern);
    }
    
    // Collect cache miss times (normal behavior)
    for (int i = 0; i < SAMPLES; i++) {
        my_flush((void*)buffer);
        
        // Generate pattern based on access type
        int pattern_type = i % 4;
        int variation = rand() % 10;
        const char* pattern = get_memory_pattern(pattern_type, variation);
        
        uint64_t start = get_time();
        volatile char temp = buffer[0];
        uint64_t time = get_time() - start;
        
        double cpu = get_cpu_usage() - start_cpu;
        timestamp += 0.01 + (rand() % 10) / 1000.0;
        
        printf("%.6f,%lu,0,normal,%.6f,%s\n", timestamp, time, cpu, pattern);
    }
    
    // Simulate Flush+Reload attack pattern
    for (int i = 0; i < SAMPLES; i++) {
        if (i % 2 == 0) {
            // Flush phase
            my_flush((void*)buffer);
            
            // Generate pattern that's consistent for Flush+Reload
            const char* pattern = get_memory_pattern(2, i % 10);
            
            uint64_t start = get_time();
            volatile char temp = buffer[0];
            uint64_t time = get_time() - start;
            
            double cpu = get_cpu_usage() - start_cpu;
            timestamp += 0.01 + (rand() % 10) / 1000.0;
            
            printf("%.6f,%lu,0,flush_reload,%.6f,%s\n", timestamp, time, cpu, pattern);
        } else {
            // Reload phase
            // Generate pattern that's consistent for Flush+Reload
            const char* pattern = get_memory_pattern(2, i % 10);
            
            uint64_t start = get_time();
            volatile char temp = buffer[0];
            uint64_t time = get_time() - start;
            
            double cpu = get_cpu_usage() - start_cpu;
            timestamp += 0.01 + (rand() % 10) / 1000.0;
            
            printf("%.6f,%lu,1,flush_reload,%.6f,%s\n", timestamp, time, cpu, pattern);
        }
    }
    
    free((void*)buffer);
    return 0;
}
