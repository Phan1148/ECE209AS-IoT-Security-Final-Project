#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <x86intrin.h>
#include <unistd.h>
#include <sys/resource.h>

#define SAMPLES 1000  // We'll get more rows because we record multiple entries per iteration
#define CACHE_LINE_SIZE 64
#define L1_WAYS 8  // L1 cache associativity

// Custom timing function
static inline uint64_t get_time() {
    unsigned int aux;
    return __rdtscp(&aux);
}

// Get CPU usage
double get_cpu_usage() {
    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    return usage.ru_utime.tv_sec + usage.ru_stime.tv_sec + 
          (usage.ru_utime.tv_usec + usage.ru_stime.tv_usec) / 1000000.0;
}

// Generate descriptive memory access pattern
const char* get_memory_pattern(int pattern_type, int variation) {
    static char pattern_str[64];
    
    switch (pattern_type) {
        case 0:
            sprintf(pattern_str, "sequential_access_%d", variation);
            break;
        case 1:
            sprintf(pattern_str, "random_access_%d", variation);
            break;
        case 2:
            sprintf(pattern_str, "stride_access_%d", variation);
            break;
        case 3:
            sprintf(pattern_str, "block_access_%d", variation);
            break;
        default:
            sprintf(pattern_str, "unknown_pattern");
    }
    
    return pattern_str;
}

// Create addresses that map to the same cache set
char** create_eviction_set(int size) {
    char** addresses = malloc(size * sizeof(char*));
    for (int i = 0; i < size; i++) {
        addresses[i] = (char*)malloc(CACHE_LINE_SIZE);
        addresses[i][0] = i;
    }
    return addresses;
}

int main() {
    srand(time(NULL));
    char** eviction_set = create_eviction_set(L1_WAYS + 1);
    double timestamp = 100.0;  // Start at a different time than Flush+Reload
    
    printf("timestamp,access_time,cache_hit,attack_type,cpu_usage,memory_access_pattern\n");
    
    double start_cpu = get_cpu_usage();
    
    // Generate normal access pattern
    for (int i = 0; i < SAMPLES; i++) {
        int index = rand() % (L1_WAYS + 1);
        
        // Generate pattern
        int pattern_type = rand() % 4;
        int variation = rand() % 10;
        const char* pattern = get_memory_pattern(pattern_type, variation);
        
        uint64_t start = get_time();
        volatile char temp = eviction_set[index][0];
        uint64_t time = get_time() - start;
        
        double cpu = get_cpu_usage() - start_cpu;
        timestamp += 0.01 + (rand() % 10) / 1000.0;
        
        int cache_hit = (time < 100) ? 1 : 0;
        printf("%.6f,%lu,%d,normal,%.6f,%s\n", timestamp, time, cache_hit, cpu, pattern);
    }
    
    // Generate Prime+Probe pattern
    for (int i = 0; i < SAMPLES; i++) {
        // Prime phase
        for (int j = 0; j < L1_WAYS; j++) {
            eviction_set[j][0] = j;
        }
        
        // Simulate victim activity
        int evicted = rand() % L1_WAYS;
        
        // Probe phase
        for (int j = 0; j < L1_WAYS; j++) {
            // Generate pattern specific to Prime+Probe
            const char* pattern = get_memory_pattern(3, j % 10);
            
            uint64_t start = get_time();
            volatile char temp = eviction_set[j][0];
            uint64_t time = get_time() - start;
            
            double cpu = get_cpu_usage() - start_cpu;
            timestamp += 0.01 + (rand() % 5) / 1000.0;
            
            int cache_hit = (j == evicted) ? 0 : 1;
            printf("%.6f,%lu,%d,prime_probe,%.6f,%s\n", timestamp, time, cache_hit, cpu, pattern);
        }
    }
    
    // Free allocated memory
    for (int i = 0; i < L1_WAYS + 1; i++) {
        free(eviction_set[i]);
    }
    free(eviction_set);
    
    return 0;
}
