/* demo/config.h.  Generated from config.h.in by configure.  */

#define HAVE_DEBUG_SYMBOLS 1
#define HAVE_SYMBOLS 1
